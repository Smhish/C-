﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace HW03
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        //設定foods字典，用來新增多個元素<string, int>的集合
        Dictionary<string, int> foods = new();

        //設定三個全域變數，分別處理「TextBox字典、TextBox名稱、TextBox輸入」
        string[] textBoxMyFoodsName = { "大麥克漢堡(大)" , "大麥克漢堡(小)" , "麥香雞漢堡(大)" , 
                                        "麥香雞漢堡(小)" , "雙層牛肉堡(大)" , "雙層牛肉堡(小)" },
                 textBoxName = { "textBox", "textBox1", "textBox2", "textBox3", "textBox4", "textBox5" },
                 textBoxCount = { "", "", "", "", "", "" };
        
        //自行設定的字典菜單
        public static void MyFoods(Dictionary<string, int> foods)
        {
            string[] name = { "大麥克漢堡(大)" , "大麥克漢堡(小)" , "麥香雞漢堡(大)" , 
                              "麥香雞漢堡(小)" , "雙層牛肉堡(大)" , "雙層牛肉堡(小)" };
            int[] money = { 150 , 90 , 140 , 80 , 160 , 100};
            for (int i = 0; i <= name.Length - 1; i++) { foods.Add(name[i], money[i]); }
        }

        public MainWindow()
        {
            InitializeComponent();
            MyFoods(foods);
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var targetTextBox = sender as TextBox; //類型轉換取得目前輸入資料的TextBox控制項
            if (targetTextBox != null) //如果類型轉換後有成功
            {
                for (int i = 0; i <= textBoxName.Length - 1; i++) //依序比對TextBox名稱
                {
                    if (targetTextBox.Name == textBoxName[i]) //如果TextBox比對後名稱相同
                    {
                        textBoxCount[i] = targetTextBox.Text; //儲存目前TextBox輸入的資料
                        break;
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            textBlock.Text = ""; //預設TextBlock物件顯示文字
            string allString = ""; //儲存購買資訊
            int allMoney = 0; //儲存購買總金額
            bool success = true , notSpace = true; //用來判斷是否正確

            for(int i = 0; i <= textBoxCount.Length - 1; i++)
            {
                string name = textBoxMyFoodsName[i];
                int money = foods[textBoxMyFoodsName[i]];
                bool NotError = int.TryParse(textBoxCount[i],out int count); //用來判斷是否正確

                if (textBoxCount[i] == "" && allString == "") //如果都沒有輸入任何購買數量
                {   notSpace = false;   }
                else if (textBoxCount[i] != "" && NotError == false) //如果有輸入購買數量，結果是錯誤
                {
                    MessageBox.Show("菜單裡輸入的數量有錯誤，請重新輸入!", "警告");
                    success = false; //代表有錯誤
                    break; //跳出迴圈
                }
                else if(count > 0) //如果有輸入購買數量，結果是正確
                {
                    allString += $"{money}元的{name}買了{count}份\r\n\r\n";
                    allMoney += money * count;
                    notSpace = true; //代表有輸入購買數量
                } 
            }

            if(success) //如果都是正確
            {
                int discount; //儲存折扣後總金額
                int bonus = Convert.ToInt32(allMoney * 0.1);

                if (allMoney >= 1000)
                {
                    discount = Convert.ToInt32(allMoney * 0.85);
                    allString += $"原先總金額為{allMoney}元，打85折後，總金額為{discount}元\r\n\r\n";
                }   
                else if (allMoney >= 500)
                {
                    discount = Convert.ToInt32(allMoney * 0.9);
                    allString += $"原先總金額為{allMoney}元，打9折後，總金額為{discount}元\r\n\r\n";
                }  
                else
                {
                    discount = allMoney;
                    allString += $"總金額為{allMoney}元\r\n\r\n";
                }

                allString += $"獲得的回饋點數為{bonus}點\r\n\r\n";

                if (notSpace) //如果有輸入購買數量
                {
                    MessageBox.Show($"訂單完成 ! 總金額為{discount}元，回饋點數為{bonus}點" , "完成訂單");
                    textBlock.Text = allString; //顯示購買資訊
                }
                else MessageBox.Show("沒有輸入購買的數量 !", "警告");
            }
        }
    }
}
