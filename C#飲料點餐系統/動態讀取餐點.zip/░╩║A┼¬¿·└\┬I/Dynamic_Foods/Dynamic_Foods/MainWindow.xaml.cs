﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dynamic_Foods
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Carry> carrys = new List<Carry>(); //新增Carry類別的carrys變數，新增多個攜帶方案的元素
        List<Drink> drinks = new List<Drink>(); //新增Drink類別的drinks變數，新增多個品項方案的元素

        public MainWindow()
        {
            InitializeComponent();

            AddNewCarry(carrys);

            AddNewDrink(drinks);

            DisplayDrinks();
        }

        private void AddNewCarry(List<Carry> mycarrys) 
        {
            mycarrys.Add( new Carry() { Name = "內用" } );
            mycarrys.Add( new Carry() { Name = "外帶" } );
        }

        private void AddNewDrink(List<Drink> mydrinks) 
        {
            mydrinks.Add( new Drink { Name = "咖啡" , Size = "大杯" , Price = "60" } );
            mydrinks.Add( new Drink { Name = "咖啡" , Size = "中杯" , Price = "50" } );
            mydrinks.Add( new Drink { Name = "紅茶" , Size = "大杯" , Price = "30" } );
            mydrinks.Add( new Drink { Name = "紅茶" , Size = "中杯" , Price = "20" } );
            mydrinks.Add( new Drink { Name = "綠茶" , Size = "大杯" , Price = "25" } );
            mydrinks.Add( new Drink { Name = "綠茶" , Size = "中杯" , Price = "20" } );
        }

        public void DisplayDrinks()
        {
            foreach(Carry c in carrys)
            {
                RadioButton rb = new RadioButton();  //新增動態RadioButton物件
                StackPanel sp = new StackPanel();    //新增動態StackPanel物件

                //動態規劃RadioButton物件的屬性-------------------------------------------------------------------
                //顯示字
                rb.Content = c.Name;
                //位置調整(右,下,左,上)
                rb.Margin = new Thickness(10,10,0,0);
                //顯示字大小調整
                rb.FontSize = 14;
                //關閉粗體效果
                rb.FontWeight = FontWeights.Normal;
                //新增到觸發事件RadioButton_Checked
                rb.Checked += RadioButton_Checked;
                //----------------------------------------------------------------------------------------------

                //將物件丟給sp群組
                sp.Children.Add(rb);

                //將群組丟給stackpanel_carry群組，丟完後，群組裡的物件由上到下依序排列
                stackpanel_carry.Children.Add(sp);
                stackpanel_carry.Orientation = Orientation.Vertical; 
            }
            
            foreach(Drink d in drinks)
            {
                CheckBox cb = new CheckBox();       //動態新增CheckBox物件
                Slider s = new Slider();            //動態新增Slider物件
                Label lb = new Label();             //動態新增Label物件
                StackPanel sp = new StackPanel();   //動態新增StackPanel物件

                //動態規劃CheckBox物件的屬性----------------------------------------------------------------------
                //顯示字
                cb.Content = $"{d.Name}   {d.Size}   {d.Price}元";
                //位置調整(右,下,左,上)
                cb.Margin = new Thickness(10, 15, 0, 0);
                //顯示字大小調整
                cb.FontSize = 14;
                //關閉粗體效果
                cb.FontWeight = FontWeights.Normal;
                //----------------------------------------------------------------------------------------------

                //動態規劃Slider物件的屬性-------------------------------------------------------------------------
                //由左到右的最大長度
                s.Width = 100;
                //進行滑動時移動多少的單位(資料繫結:「來源Object」)
                s.Value = 0;
                //最小數量單位
                s.Minimum = 0;
                //最大數量單位
                s.Maximum = 20;
                //位置調整(右,下,左,上)
                s.Margin = new Thickness(10, 15, 0, 0);
                //開啟刻度固定比例功能(每次移動固定為1單位為準)
                s.IsSnapToTickEnabled = true;
                //開啟鼠標點擊決定滑塊移動多少的單位
                s.IsMoveToPointEnabled = true;
                //進行滑動時捕捉目前移動到的單位並顯示(黑框灰底黑字)
                s.AutoToolTipPlacement = System.Windows.Controls.Primitives.AutoToolTipPlacement.BottomRight;
                //----------------------------------------------------------------------------------------------

                //動態規劃Label物件的屬性--------------------------------------------------------------------------
                //顯示字(資料繫結:「目標Dependency Object」)
                lb.Content = s.Value;
                //位置調整(右,下,左,上)
                lb.Margin = new Thickness(0, 8, 0, 0);
                //顯示字大小調整
                lb.FontSize = 14;
                //關閉粗體效果
                lb.FontWeight = FontWeights.Normal;
                //(資料繫結:「參數化建構:Binding(String)」)
                Binding binding = new Binding("Value");
                //(資料繫結:「綁定來源Object」)
                binding.Source = s;
                //(資料繫結:「ContentProperty去識別目標的Content屬性，將binding綁定來源傳到目標的Content屬性」)
                lb.SetBinding(ContentProperty, binding);
                //----------------------------------------------------------------------------------------------

                //將物件丟給sp群組，丟完後，群組裡的物件由左到右依序排列
                sp.Children.Add(cb);
                sp.Children.Add(s);
                sp.Children.Add(lb);
                sp.Orientation = Orientation.Horizontal;

                //將群組丟給stackpanel_drink群組，丟完後，群組裡的物件由上到下依序排列
                stackpanel_drink.Children.Add(sp);
                stackpanel_drink.Orientation = Orientation.Vertical;
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;

            if (rb == null) { return; } //沒有此物件則跳出事件
            
            for (int i = 0; i < stackpanel_carry.Children.Count; i++)
            {
                //依序處理stackpanel_carry每個群組中的多個sp群組裡面RadioButton物件
                StackPanel sps = stackpanel_carry.Children[i] as StackPanel; 
                RadioButton rbs = sps.Children[0] as RadioButton;

                if(rbs != null)
                {
                    if (rbs == rb) { rbs.IsChecked = true; } //目前rbs物件的核取方塊設為true
                    else { rbs.IsChecked = false; } //目前rbs物件的核取方塊設為false
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            textblock_statement.Text = "";
            string allStr = ""; //全部的購買資訊
            int allMoney = 0; //原金額
            double salfMoney = 0; //折扣後金額
            bool success = true; //判斷是否過程皆是正確執行

            for (int i = 0; i < stackpanel_carry.Children.Count; i++)
            {
                //依序處理stackpanel_carry每個群組中的多個sp群組裡面RadioButton物件
                StackPanel sps = stackpanel_carry.Children[i] as StackPanel;
                RadioButton rbs = sps.Children[0] as RadioButton;

                if(rbs != null && rbs.IsChecked == true ) //有選擇方案時
                {
                    allStr += $"您所選擇的為{rbs.Content}方案\r\n";
                    break;
                }

                if(i + 1 == stackpanel_carry.Children.Count) //沒有選擇方案時
                { 
                    MessageBox.Show("未選擇攜帶食物飲料的方案，請重新輸入 !","警告");
                    success = false;
                }
            }

            for(int i = 0; i < stackpanel_drink.Children.Count; i++)
            {
                StackPanel sp = stackpanel_drink.Children[i] as StackPanel;
                CheckBox cb = sp.Children[0] as CheckBox;
                Label lb = sp.Children[2] as Label;

                if(cb != null && lb != null)
                {
                    int price = Convert.ToInt32(drinks[i].Price); //目前商品價格
                    int num = Convert.ToInt32(lb.Content); //目前商品購買數量

                    if (cb.IsChecked == true && num > 0) //目前商品有購買，將購買資訊與總金額加上去
                    {
                        allStr += $"{drinks[i].Size}{price}元的{drinks[i].Name}購買了{num}份\r\n";
                        allMoney += price * num;
                    } 
                }
            }
            
            if(allMoney <= 0) //沒有購買任何品項
            {
                MessageBox.Show("沒有任何輸入或勾選要購買的品項，請重新輸入 !", "警告");
            }
            else if(success == true)//有購買任何品項
            {
                MessageBox.Show("恭喜您完成了訂單 !", "訂購完成");
                if (allMoney >= 500) 
                {
                    allStr += $"原花費金額為{allMoney}元\r\n打8折後，折扣後";
                    salfMoney = allMoney * 0.8;
                }
                else if (allMoney >= 300)
                {
                    allStr += $"原花費金額為{allMoney}元\r\n打85折後，折扣後";
                    salfMoney = allMoney * 0.85;
                }
                else if (allMoney >= 200)
                {
                    allStr += $"原花費金額為{allMoney}元\r\n打9折後，折扣後";
                    salfMoney = allMoney * 0.9;
                }
                else { salfMoney = allMoney; }

                allStr += $"花費總金額為{Convert.ToInt32(salfMoney)}元\r\n";

                //將購買資訊印在textblock_statement物件上面
                textblock_statement.Text += allStr;
            }   
        }
    }  
}
