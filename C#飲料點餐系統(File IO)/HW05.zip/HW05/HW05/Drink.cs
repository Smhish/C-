﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW05
{
    internal class Drink
    {
        //飲料品項名稱
        public string Name { get; set; }

        //飲料品項大小
        public string Size { get; set; }

        //飲料品項價格
        public string Price { get; set; }
    }
}
