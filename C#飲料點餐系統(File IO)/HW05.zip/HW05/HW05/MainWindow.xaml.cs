﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HW05
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Drink> drinks = new List<Drink>();
        List<Order> order = new List<Order>();

        public MainWindow()
        {
            InitializeComponent();
            AddNewDrink(drinks);
            AddNewDisplay();
        }

        //建構Drink類別的變數，加入飲料品項
        private void AddNewDrink(List<Drink> mydrinks)
        {
            //【OpenFileDialog類別】，可讓使用者唯讀要開啟的一個或多個檔案，來指定檔名
            OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog();

            //【Filter屬性】，可決定在 OpenFileDialog 或 SaveFileDialog 中顯示的檔案類型
            //【 變數名稱.Filter = "檔案類型標籤|檔案類型" + ...; 】，語法的設定
            //【...】擴建多個不同【"檔案類型標籤|檔案類型"】，加上【"|"】可以去篩選選項，做檔案類型區分
            dialog.Filter = "CSV檔案|*.csv" + "|" +
                            "TXT檔案|*.txt" + "|" +
                            "全部檔案|*.*";

            //【ShowDialog()屬性】，判斷顯示的檔案類型的視窗對話方塊，按一下[確定]則返回為ture；否則返回為false
            if (dialog.ShowDialog() == true)
            {
                //【FileName屬性】，取得目前選擇的檔案路徑
                string pash = dialog.FileName;

                //【StreamReader類別】，為特定編碼的字元輸入，取得目前選擇的檔案內的文字資訊
                //【Encoding.Default屬性】，一律取得.NET 執行的預設UTF-8系統編碼(不支援ANSI系統locale的遺留（legacy）編碼，會產生亂碼)
                //【Encoding.GetEncoding()屬性】，確認【()括號】裡面讀取資料時的格式編碼 (可支援ANSI系統的編碼)
                //【Encoding.GetEncoding(950)屬性】，取得系統的微軟繁體中文代碼頁的編碼
                StreamReader sr = new StreamReader(pash, Encoding.Default);

                //取得目前選擇檔案的文字內容
                string txt = sr.ReadToEnd();

                //使用字串陣列分別儲存【'\r', '\n'】換行字元隔開的文字內容
                string[] newlines = txt.Split('\r', '\n');

                //依序讀取每一行字串的文字內容
                foreach (string n in newlines)
                {
                    //使用字串陣列分別儲存【,】逗號字元隔開的文字內容
                    string[] comma = n.Split(',');

                    //分別儲存飲料品項的名稱、大小、價格
                    string name = "", size = "", price = "";

                    //設定計數變數
                    int i = 1;

                    //依序讀取逗號隔開字串的文字內容
                    foreach (string c in comma)
                    {
                        if (i == 1) { name = c; i++; }
                        else if (i == 2) { size = c; i++; }
                        else if (i == 3)
                        {
                            price = c;

                            //新增我的飲料品項到Drink類別的drinks變數
                            mydrinks.Add(new Drink { Name = name, Size = size, Price = price });

                            //跳出迴圈
                            break;
                        }
                    }
                }
            }
        }

        //建構動態規劃的飲料品項物件
        private void AddNewDisplay()
        {
            foreach(Drink d in drinks)
            {
                //動態規劃物件、群組
                CheckBox cb = new CheckBox();
                Slider sl = new Slider();
                Label lb = new Label();
                Label lb_count = new Label();
                StackPanel sp = new StackPanel();

                //動態規劃CheckBox物件的屬性
                cb.Margin = new Thickness(2, 0, 0, 0);
                cb.Content = d.Name  + "  " + 
                             d.Size  + "  " +
                             d.Price + "元";
                
                //動態規劃Slider物件的屬性
                sl.Margin = new Thickness(2, 0, 0, 0);
                sl.Width = 100;
                sl.Value = 0;
                sl.Minimum = 0;
                sl.Maximum = 30;
                sl.IsSnapToTickEnabled = true;
                sl.IsMoveToPointEnabled = true;
                sl.AutoToolTipPlacement = System.Windows.Controls.Primitives.AutoToolTipPlacement.BottomRight;


                //動態規劃Label物件的屬性
                lb.Margin = new Thickness(0, -4, 0, 0);
                lb.Content = sl.Value;
                Binding binding = new Binding("Value");
                binding.Source = sl;
                lb.SetBinding(ContentProperty, binding);

                //動態規劃Label購買數量物件的屬性
                lb_count.Margin = new Thickness(0, -4, 0, 0);
                lb_count.Content = "個";

                //將動態規劃的物件，放進動態規劃的StackPanel群組，由左到右依序排列物件
                sp.Children.Add(cb);
                sp.Children.Add(sl);
                sp.Children.Add(lb);
                sp.Children.Add(lb_count);
                sp.Margin = new Thickness(0, 5, 0, 0);
                sp.Orientation = Orientation.Horizontal;

                //將動態規劃的群組，放進靜態規劃的stackpanel_drinks群組，由上到下依序排列群組
                drink_menu.Children.Add(sp);
                drink_menu.Orientation = Orientation.Vertical;
            }
        }

        //按下訂購完成的Button按鈕，觸發事件動作
        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            //檢查購買的飲料品項，接著訂單明細輸出到Order類別的order變數
            PlaceOrder(order);

            //將Order類別的order變數，訂單明細輸出到txt文字檔案、TextBlock物件
            DisplayOrderDetail(order);
        }

        //檢查動態規劃的所有CheckBox狀態，並判斷是否滿足條件可以折扣，完成後輸出訂單明細，給Order類別的變數
        private void PlaceOrder(List<Order> myorder)
        {
            string orderDetail = "購買的訂單明細如下:\n";
            double money = 0;
            int i;

            //判斷是否有購買飲料品項，預設false，代表目前沒有購買品項
            bool success = false; 

            //先清空先前設定的訂單明細與總價格
            order.Clear();

            //確認取餐運送方式
            for (i = 0; i < 2; i++)
            {
                RadioButton rb = delivery.Children[i] as RadioButton;

                if(rb != null)
                {
                    //如果是有勾選取餐的RadioButton物件
                    if (rb.IsChecked == true)
                    {
                        orderDetail += $"選擇的取餐方式為{rb.Content}\r\n";
                        break;
                    }
                    //如果都沒有勾選取餐的RadioButton物件
                    else if (i == 1)
                    {
                        //跳出訊息方塊顯示錯誤
                        MessageBox.Show("沒有勾選取餐方式 !", "警告");

                        //跳出函數
                        return;
                    }
                }
            }
            
            //確認勾選與數量的飲料品項
            i = 0; foreach (Drink d in drinks)
            {
                StackPanel sl = drink_menu.Children[i] as StackPanel;
                CheckBox cb = sl.Children[0] as CheckBox;
                Label lb = sl.Children[2] as Label;

                //確認是否有cb、lb的物件
                if (cb != null && lb != null)
                {
                    //如果有勾選目前品項
                    if (cb.IsChecked == true)
                    {
                        //目前品項的價格
                        int price = Convert.ToInt32(d.Price);

                        //目前品項的購買數量
                        int count = Convert.ToInt32(lb.Content);

                        //如果有勾選購買的飲料品項，沒有輸入數量
                        if(count == 0)
                        {
                            //跳出訊息方塊，顯示錯誤
                            MessageBox.Show("沒有輸入已勾選飲料品項的數量 !", "錯誤");

                            //跳出函數
                            return ;
                        }

                        //儲存訂單明細
                        orderDetail += $"{d.Price}元的{d.Name}{d.Size}購買了{count}份\r\n";

                        //儲存購買的總金額
                        money += price * count;

                        //代表有購買飲料品項，設定為true
                        success = true;
                    }
                }
                //計數變數增加
                i++;
            }

            //如果沒有購買飲料品項
            if(success == false)
            {
                //跳出訊息方塊，顯示錯誤
                MessageBox.Show("沒有勾選任何購買的飲料品項 !", "錯誤");

                //跳出函數
                return;
            }

            //判斷購買總金額是否有滿足條件折扣
            if (money >= 500) { orderDetail += $"總價格{money}元，打8折後，購買的總金額為{Convert.ToInt32(money * 0.8)}元"; }
            else if (money >= 300) { orderDetail += $"總價格{money}元，打85折後，購買的總金額為{Convert.ToInt32(money * 0.85)}元"; }
            else if (money >= 200) { orderDetail += $"總價格{money}元，打9折後，購買的總金額為{Convert.ToInt32(money * 0.9)}元"; }
            else { orderDetail += $"購買的總金額為{Convert.ToInt32(money)}元"; }

            //將訂單明細儲存到Order類別的order變數
            order.Add(new Order { OrderDetail = orderDetail});
        }

        //將Order類別的變數，訂單明細輸出到TextBlock物件、txt檔案
        private void DisplayOrderDetail(List<Order> myorder)
        {
            //清空先前輸出到TextBlock物件的訂單明細
            drink_orderdetail.Text = "";

            //讀取Order類別的order變數，輸出訂單明細
            foreach (Order o in order)
            {
                //將訂單明細輸出到TextBlock物件
                drink_orderdetail.Text += o.OrderDetail;

                //【OpenFileDialog類別】，可讓使用者唯讀要開啟的一個或多個檔案，來指定檔名
                OpenFileDialog dialog = new OpenFileDialog();

                //【Filter屬性】，可決定在 OpenFileDialog 或 SaveFileDialog 中顯示的檔案類型
                //【 變數名稱.Filter = "檔案類型標籤|檔案類型" + ...; 】，語法的設定
                //【...】擴建多個不同【"檔案類型標籤|檔案類型"】，加上【"|"】可以去篩選選項做檔案類型區分
                dialog.Filter = "TXT檔案|*.txt" + "|" +
                                "全部檔案|*.*";

                //【ShowDialog()屬性】，判斷顯示的檔案類型的視窗對話方塊，按一下[確定]則返回為ture；否則返回為false
                if (dialog.ShowDialog() == true)
                {
                    //【FileName屬性】，取得目前選擇的檔案路徑
                    string pash = dialog.FileName;

                    //【using()】， 【()括號】內的Dispose當使用它的程式碼完成時，語句會自動呼叫物件
                    using (StreamWriter sw = new StreamWriter(pash))
                    {
                        //將訂單明細輸出到txt檔案
                        sw.WriteLine(o.OrderDetail);
                    }
                }
                //如果沒有輸出
                else { MessageBox.Show("沒有成功將訂單明細寫入到txt檔案 !", "警告"); }
            }
        }

        //按下RadioButton物件，觸發事件，切換取餐運送方式
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;

            if(rb != null)
            {
                for(int i = 0; i < 2; i++)
                {
                    RadioButton rb_save = delivery.Children[i] as RadioButton;

                    if(rb_save != null)
                    {
                        if(rb != rb_save)
                        {
                            rb_save.IsChecked = false;
                        }
                    }
                }
            }
        }
    }
}
