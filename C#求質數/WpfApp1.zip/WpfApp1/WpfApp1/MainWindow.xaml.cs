﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent(); //載入XAML UI內容的角色
        }

        public static string Blank(int Max, int Min) //回傳多少(全形)空白的字串
        {
            string str = ""; //設定字串型別str

            int number_of_times = Number_Of_Digits(Max) - Number_Of_Digits(Min); 
            //"Max位數"與"Min位數"相減，得出的數值執行多少次迴圈

            for (int i = 1; i <= number_of_times; i++)
            {
                str += "  "; //將全形(空白)儲存到str字串
            }
            return str; //回傳字串str
        }

        public static int Number_Of_Digits(int nod) //回傳整數nod有多少位數
        {
            int a; //設定整數型別a
            for (a = 1; nod >= 10; a++) nod = nod / 10; //求nod的位數
            return a; //回傳nod位數
        }

        private void Button_Click(object sender, RoutedEventArgs e) //定義button物件
        {
            textBox2.Text = ""; //預設初始化

            string input = Convert.ToString(textBox1.Text); 
            //先讀取textBox1物件輸入的字串資料，儲存到input

            int N; //正整數範圍

            if (int.TryParse(input, out N) == false) //如果input是整數，N = input
            {
                N = 0; //如果input不是整數，設定N範圍以外
            }

            if (N >= 1) //如果N是正整數
            {
                for (int i = 2; i <= N; i++) //計算 (2 ~ N) 有多少正整數
                {

                    for (int j = 1; j < i; j++) //根據j = (1 ~ i-1) ，來計算 (i % j) 是否為質數
                    {
                        if (i == 2 || ((i % j != 0) && (j + 1 == i))) //如果i是質數
                        {
                            //textBox2.Text += "．" +(i) + ("的倍數 : "); //未整版
                            textBox2.Text += "．" + (Blank(N, i)) + (i) + ("的倍數 : "); //有整版

                            for (int k = 1; k * i <= N; k++) //處理目前質數i的倍數範圍
                            {
                                textBox2.Text += (k * i); //質數i的倍數顯示在textBox2物件

                                if ((k + 1) * i <= N) //如果質數i的倍數不是最後一個
                                {
                                    textBox2.Text += " , "; //添加逗號
                                }
                            }
                            textBox2.Text += "\r\n"; //換行排版
                        }
                        else if ((i % j == 0) && (j != 1))//如果不是質數
                        {
                            break; //跳過此值
                        }
                    }
                }
                if (N == 1) textBox2.Text += "沒有任何質數!!!"; 
                //如果N是正整數，範圍裡沒有任何質數，跳出此訊息
            }
            else
            {
                MessageBox.Show("輸入的值不是正整數，請重新輸入!!!", "警告"); 
                //彈出一個MessageBox提示使用者重新輸入

                textBox1.Text = ""; 
                //清空textBox1物件輸入的錯誤資料
            }
        }

        private void TextBox1_TextChanged(object sender, TextChangedEventArgs e) //定義textBox1物件
        {

        }

        private void TextBox2_TextChanged(object sender, TextChangedEventArgs e) //定義textBox2物件
        {

        }
    }
}
