﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public static string Letter_Segmentation(string str)
        {
            string save = "", output = ""; //字串型別save、output初始化空字串
            bool judge = false; //judge預設false，用來判斷是否換行
            save = str; //save儲存str的輸入字串

            /*//此為字串分割函式，也可以不用設定；如要設定32行請註解
            string[] subs = str.Split(' ' , ',' , '.');

            foreach (var sub in subs)
            {
                save += sub;
            }
            */

            save += '\n'; //save設定結尾換行

            for (int i = 0;'a' + i <= 'z'; i++) //依序處理每個小寫字母，字串中出現的數量
            {
                int n = 0; //目前讀取小寫字母的初始數量 = 0
                for (int j = 0; save[j] != '\n'; j++)
                {
                    if (save[j] == 'a' + i) //如果"字串save目前讀取字元"與"目前讀取小寫字母"相同
                    {
                        n = n + 1; //數量 + 1
                    }         
                }
                if (n != 0) //如果目前讀取小寫字母數量不為 0
                {
                    if (judge) output += "\n"; //如果judge = true，代表先前其它字母有數量，執行換行
                    output += $"{Convert.ToChar('a' + i)}\t:{n}個"; //儲存目前讀取小寫字母的出現數量
                    judge = true; //設定judge = true
                }
            }
            return output; //回傳整理後要輸出的字串
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            textBlock.Text = ""; //每次輸入時清空textBlock物件的字串資料，非常重要!!! 
            string input = textBox.Text; //輸入的字串資料
            textBlock.Text += Letter_Segmentation(input); //輸出整理後的字串資料
        }
    }
}
